﻿namespace Practica_4
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            label4 = new Label();
            label5 = new Label();
            label6 = new Label();
            label7 = new Label();
            button1 = new Button();
            button2 = new Button();
            button3 = new Button();
            textBox1 = new TextBox();
            textBox2 = new TextBox();
            textBox3 = new TextBox();
            textBox4 = new TextBox();
            textBox5 = new TextBox();
            textBox6 = new TextBox();
            pictureBox1 = new PictureBox();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Tahoma", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.Location = new Point(115, 19);
            label1.Name = "label1";
            label1.Size = new Size(568, 28);
            label1.TabIndex = 0;
            label1.Text = "INTRODUCE LAS DIMENCIONES DEL CILINDRO ";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI Emoji", 12F, FontStyle.Bold);
            label2.Location = new Point(87, 137);
            label2.Name = "label2";
            label2.Size = new Size(76, 27);
            label2.TabIndex = 1;
            label2.Text = "RADIO";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Segoe UI Emoji", 12F, FontStyle.Bold);
            label3.Location = new Point(87, 226);
            label3.Name = "label3";
            label3.Size = new Size(89, 27);
            label3.TabIndex = 2;
            label3.Text = "ALTURA";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Segoe UI Emoji", 12F, FontStyle.Bold);
            label4.Location = new Point(87, 424);
            label4.Name = "label4";
            label4.Size = new Size(119, 27);
            label4.TabIndex = 3;
            label4.Text = "BASE AREA";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Segoe UI Emoji", 12F, FontStyle.Bold);
            label5.Location = new Point(87, 498);
            label5.Name = "label5";
            label5.Size = new Size(153, 27);
            label5.TabIndex = 4;
            label5.Text = "LATERAL AREA";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Segoe UI Emoji", 12F, FontStyle.Bold);
            label6.Location = new Point(87, 564);
            label6.Name = "label6";
            label6.Size = new Size(132, 27);
            label6.TabIndex = 5;
            label6.Text = "TOTAL AREA";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Font = new Font("Segoe UI Emoji", 12F, FontStyle.Bold);
            label7.Location = new Point(87, 643);
            label7.Name = "label7";
            label7.Size = new Size(112, 27);
            label7.TabIndex = 6;
            label7.Text = "VOLUMEN";
            // 
            // button1
            // 
            button1.Location = new Point(94, 303);
            button1.Name = "button1";
            button1.Size = new Size(146, 57);
            button1.TabIndex = 7;
            button1.Text = "CALCULAR ";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // button2
            // 
            button2.Location = new Point(321, 303);
            button2.Name = "button2";
            button2.Size = new Size(146, 57);
            button2.TabIndex = 8;
            button2.Text = "BORRAR";
            button2.UseVisualStyleBackColor = true;
            button2.Click += button2_Click;
            // 
            // button3
            // 
            button3.Location = new Point(550, 303);
            button3.Name = "button3";
            button3.Size = new Size(146, 57);
            button3.TabIndex = 9;
            button3.Text = "SALIR ";
            button3.UseVisualStyleBackColor = true;
            button3.Click += button3_Click;
            // 
            // textBox1
            // 
            textBox1.Font = new Font("Segoe UI Emoji", 13.8F, FontStyle.Bold);
            textBox1.Location = new Point(321, 137);
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(96, 38);
            textBox1.TabIndex = 10;
            // 
            // textBox2
            // 
            textBox2.Font = new Font("Segoe UI Emoji", 13.8F, FontStyle.Bold);
            textBox2.Location = new Point(321, 229);
            textBox2.Name = "textBox2";
            textBox2.Size = new Size(96, 38);
            textBox2.TabIndex = 11;
            // 
            // textBox3
            // 
            textBox3.Font = new Font("Segoe UI Emoji", 13.8F, FontStyle.Bold);
            textBox3.Location = new Point(321, 424);
            textBox3.Name = "textBox3";
            textBox3.Size = new Size(96, 38);
            textBox3.TabIndex = 12;
            // 
            // textBox4
            // 
            textBox4.Font = new Font("Segoe UI Emoji", 13.8F, FontStyle.Bold);
            textBox4.Location = new Point(321, 498);
            textBox4.Name = "textBox4";
            textBox4.Size = new Size(96, 38);
            textBox4.TabIndex = 13;
            // 
            // textBox5
            // 
            textBox5.Font = new Font("Segoe UI Emoji", 13.8F, FontStyle.Bold);
            textBox5.Location = new Point(321, 564);
            textBox5.Name = "textBox5";
            textBox5.Size = new Size(96, 38);
            textBox5.TabIndex = 14;
            // 
            // textBox6
            // 
            textBox6.Font = new Font("Segoe UI Emoji", 13.8F, FontStyle.Bold);
            textBox6.Location = new Point(321, 643);
            textBox6.Name = "textBox6";
            textBox6.Size = new Size(96, 38);
            textBox6.TabIndex = 15;
            // 
            // pictureBox1
            // 
            pictureBox1.Image = (Image)resources.GetObject("pictureBox1.Image");
            pictureBox1.Location = new Point(528, 86);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(178, 176);
            pictureBox1.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox1.TabIndex = 16;
            pictureBox1.TabStop = false;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.Fuchsia;
            ClientSize = new Size(777, 709);
            Controls.Add(pictureBox1);
            Controls.Add(textBox6);
            Controls.Add(textBox5);
            Controls.Add(textBox4);
            Controls.Add(textBox3);
            Controls.Add(textBox2);
            Controls.Add(textBox1);
            Controls.Add(button3);
            Controls.Add(button2);
            Controls.Add(button1);
            Controls.Add(label7);
            Controls.Add(label6);
            Controls.Add(label5);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Icon = (Icon)resources.GetObject("$this.Icon");
            Name = "Form1";
            Text = "DIMENCIONES DE CILINDRO ";
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Label label2;
        private Label label3;
        private Label label4;
        private Label label5;
        private Label label6;
        private Label label7;
        private Button button1;
        private Button button2;
        private Button button3;
        private TextBox textBox1;
        private TextBox textBox2;
        private TextBox textBox3;
        private TextBox textBox4;
        private TextBox textBox5;
        private TextBox textBox6;
        private PictureBox pictureBox1;
    }
}
