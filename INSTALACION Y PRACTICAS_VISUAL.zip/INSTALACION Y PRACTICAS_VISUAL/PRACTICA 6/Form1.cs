using System.Drawing;

namespace PRACTICA_6
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            double v1, cent1;
            v1 = double.Parse(Valor.Text);
            cent1 = (v1 - 32) * (5.0 / 9.0);
            Resultado.Text = cent1.ToString();
            label2.Text = " Centigrados";

        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            double v1, farh1;
            v1 = double.Parse(Valor.Text);
            farh1 = v1 * (9.0 / 5.0) + 32;
            Resultado.Text = farh1.ToString();
            label2.Text = " Fahrenheit";

        }

        private void button2_Click_1(object sender, EventArgs e)
        {
            Valor.Text = " ";
            Resultado.Text = " ";
        }
    }
}
