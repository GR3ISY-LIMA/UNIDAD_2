﻿namespace PRACTICA_6
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            label4 = new Label();
            label5 = new Label();
            button3 = new Button();
            Valor = new TextBox();
            Resultado = new TextBox();
            button1 = new Button();
            button2 = new Button();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI Emoji", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.Location = new Point(37, 65);
            label1.Name = "label1";
            label1.Size = new Size(91, 31);
            label1.TabIndex = 0;
            label1.Text = "DATOS";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI Emoji", 12F, FontStyle.Bold);
            label2.Location = new Point(75, 148);
            label2.Name = "label2";
            label2.Size = new Size(171, 27);
            label2.TabIndex = 1;
            label2.Text = "INGRESA VALOR";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Segoe UI Emoji", 12F, FontStyle.Bold);
            label3.Location = new Point(37, 221);
            label3.Name = "label3";
            label3.Size = new Size(284, 27);
            label3.TabIndex = 2;
            label3.Text = "OPCIONES DE CONVERSION";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Segoe UI Emoji", 12F, FontStyle.Bold);
            label4.Location = new Point(37, 431);
            label4.Name = "label4";
            label4.Size = new Size(253, 27);
            label4.TabIndex = 3;
            label4.Text = "RESULTADO EN GRADOS";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Segoe UI Emoji", 12F, FontStyle.Bold);
            label5.Location = new Point(75, 513);
            label5.Name = "label5";
            label5.Size = new Size(275, 27);
            label5.TabIndex = 4;
            label5.Text = "EQUIVALENTE EN GRADOS:";
            // 
            // button3
            // 
            button3.BackColor = Color.Yellow;
            button3.Font = new Font("Segoe UI Emoji", 12F, FontStyle.Bold);
            button3.Location = new Point(457, 279);
            button3.Name = "button3";
            button3.Size = new Size(177, 53);
            button3.TabIndex = 7;
            button3.Text = "CENTIGRADOS";
            button3.UseVisualStyleBackColor = false;
            button3.Click += button3_Click;
            // 
            // Valor
            // 
            Valor.Font = new Font("Segoe UI Emoji", 12F, FontStyle.Bold);
            Valor.Location = new Point(243, 151);
            Valor.Name = "Valor";
            Valor.Size = new Size(153, 34);
            Valor.TabIndex = 8;
            // 
            // Resultado
            // 
            Resultado.Font = new Font("Segoe UI Emoji", 12F, FontStyle.Bold);
            Resultado.Location = new Point(182, 561);
            Resultado.Name = "Resultado";
            Resultado.Size = new Size(153, 34);
            Resultado.TabIndex = 9;
            // 
            // button1
            // 
            button1.BackColor = Color.Yellow;
            button1.Font = new Font("Segoe UI Emoji", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button1.Location = new Point(37, 284);
            button1.Name = "button1";
            button1.Size = new Size(187, 48);
            button1.TabIndex = 10;
            button1.Text = "FARHRENHEIT";
            button1.UseVisualStyleBackColor = false;
            button1.Click += button1_Click_1;
            // 
            // button2
            // 
            button2.BackColor = Color.Yellow;
            button2.Font = new Font("Segoe UI Emoji", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button2.Location = new Point(243, 349);
            button2.Name = "button2";
            button2.Size = new Size(173, 51);
            button2.TabIndex = 11;
            button2.Text = "BORRAR";
            button2.UseVisualStyleBackColor = false;
            button2.Click += button2_Click_1;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(255, 224, 192);
            ClientSize = new Size(676, 623);
            Controls.Add(button2);
            Controls.Add(button1);
            Controls.Add(Resultado);
            Controls.Add(Valor);
            Controls.Add(button3);
            Controls.Add(label5);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Icon = (Icon)resources.GetObject("$this.Icon");
            Name = "Form1";
            Text = "conversiones";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Label label2;
        private Label label3;
        private Label label4;
        private Label label5;
        private Button button3;
        private TextBox Valor;
        private TextBox Resultado;
        private Button button1;
        private Button button2;
    }
}
