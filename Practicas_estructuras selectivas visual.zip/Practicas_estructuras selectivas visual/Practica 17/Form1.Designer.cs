﻿namespace Practica_17
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            label1 = new Label();
            textBox1 = new TextBox();
            textBox2 = new TextBox();
            textBox3 = new TextBox();
            label2 = new Label();
            label3 = new Label();
            label4 = new Label();
            textBox4 = new TextBox();
            textBox5 = new TextBox();
            textBox6 = new TextBox();
            button3 = new Button();
            button2 = new Button();
            button1 = new Button();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.BackColor = Color.SpringGreen;
            label1.Font = new Font("SWItalt", 13.7999992F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.ForeColor = Color.DarkSlateGray;
            label1.Location = new Point(84, 24);
            label1.Name = "label1";
            label1.Size = new Size(626, 30);
            label1.TabIndex = 0;
            label1.Text = "ORDENAR 3 NUMEROS DE MAYOR A MENOR ";
            // 
            // textBox1
            // 
            textBox1.Font = new Font("STKaiti", 16.2F, FontStyle.Bold);
            textBox1.Location = new Point(134, 147);
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(103, 43);
            textBox1.TabIndex = 1;
            // 
            // textBox2
            // 
            textBox2.Font = new Font("STKaiti", 16.2F, FontStyle.Bold);
            textBox2.Location = new Point(556, 147);
            textBox2.Name = "textBox2";
            textBox2.Size = new Size(103, 43);
            textBox2.TabIndex = 2;
            // 
            // textBox3
            // 
            textBox3.Font = new Font("STKaiti", 16.2F, FontStyle.Bold);
            textBox3.Location = new Point(341, 147);
            textBox3.Name = "textBox3";
            textBox3.Size = new Size(103, 43);
            textBox3.TabIndex = 3;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI Emoji", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label2.Location = new Point(170, 220);
            label2.Name = "label2";
            label2.Size = new Size(30, 31);
            label2.TabIndex = 4;
            label2.Text = "A";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Segoe UI Emoji", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label3.Location = new Point(377, 220);
            label3.Name = "label3";
            label3.Size = new Size(28, 31);
            label3.TabIndex = 5;
            label3.Text = "B";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Segoe UI Emoji", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label4.Location = new Point(598, 220);
            label4.Name = "label4";
            label4.Size = new Size(29, 31);
            label4.TabIndex = 6;
            label4.Text = "C";
            // 
            // textBox4
            // 
            textBox4.Font = new Font("STKaiti", 16.2F, FontStyle.Bold);
            textBox4.Location = new Point(134, 442);
            textBox4.Name = "textBox4";
            textBox4.Size = new Size(103, 43);
            textBox4.TabIndex = 7;
            // 
            // textBox5
            // 
            textBox5.Font = new Font("STKaiti", 16.2F, FontStyle.Bold);
            textBox5.Location = new Point(341, 442);
            textBox5.Name = "textBox5";
            textBox5.Size = new Size(103, 43);
            textBox5.TabIndex = 8;
            // 
            // textBox6
            // 
            textBox6.Font = new Font("STKaiti", 16.2F, FontStyle.Bold);
            textBox6.Location = new Point(556, 442);
            textBox6.Name = "textBox6";
            textBox6.Size = new Size(103, 43);
            textBox6.TabIndex = 9;
            // 
            // button3
            // 
            button3.BackColor = Color.DeepSkyBlue;
            button3.Font = new Font("Segoe UI Emoji", 13.8F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 0);
            button3.Location = new Point(556, 340);
            button3.Name = "button3";
            button3.Size = new Size(113, 39);
            button3.TabIndex = 12;
            button3.Text = "Salir";
            button3.UseVisualStyleBackColor = false;
            button3.Click += button3_Click;
            // 
            // button2
            // 
            button2.BackColor = Color.DeepSkyBlue;
            button2.Font = new Font("Segoe UI Emoji", 16.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button2.Location = new Point(341, 340);
            button2.Name = "button2";
            button2.Size = new Size(115, 42);
            button2.TabIndex = 13;
            button2.Text = "Borrar";
            button2.UseVisualStyleBackColor = false;
            button2.Click += button2_Click_1;
            // 
            // button1
            // 
            button1.BackColor = Color.DeepSkyBlue;
            button1.Font = new Font("Segoe UI Emoji", 13.8F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 0);
            button1.Location = new Point(116, 340);
            button1.Name = "button1";
            button1.Size = new Size(153, 51);
            button1.TabIndex = 14;
            button1.Text = "Ordenar";
            button1.UseVisualStyleBackColor = false;
            button1.Click += button1_Click_1;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.Cyan;
            ClientSize = new Size(785, 541);
            Controls.Add(button1);
            Controls.Add(button2);
            Controls.Add(button3);
            Controls.Add(textBox6);
            Controls.Add(textBox5);
            Controls.Add(textBox4);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(textBox3);
            Controls.Add(textBox2);
            Controls.Add(textBox1);
            Controls.Add(label1);
            Icon = (Icon)resources.GetObject("$this.Icon");
            Name = "Form1";
            Text = "ORDENAR DE MAYOR A MENOR ";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private TextBox textBox1;
        private TextBox textBox2;
        private TextBox textBox3;
        private Label label2;
        private Label label3;
        private Label label4;
        private TextBox textBox4;
        private TextBox textBox5;
        private TextBox textBox6;
        private Button button3;
        private Button button2;
        private Button button1;
    }
}
