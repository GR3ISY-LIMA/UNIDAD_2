﻿namespace Practica_19
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            label4 = new Label();
            textBox1 = new TextBox();
            textBox2 = new TextBox();
            textBox3 = new TextBox();
            textBox4 = new TextBox();
            button1 = new Button();
            textBox5 = new TextBox();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI Emoji", 16.2F, FontStyle.Bold | FontStyle.Italic);
            label1.Location = new Point(76, 145);
            label1.Name = "label1";
            label1.Size = new Size(194, 37);
            label1.TabIndex = 0;
            label1.Text = "Calificacion 1";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI Emoji", 16.2F, FontStyle.Bold | FontStyle.Italic);
            label2.Location = new Point(76, 227);
            label2.Name = "label2";
            label2.Size = new Size(194, 37);
            label2.TabIndex = 1;
            label2.Text = "Calificacion 2";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Segoe UI Emoji", 16.2F, FontStyle.Bold | FontStyle.Italic);
            label3.Location = new Point(76, 314);
            label3.Name = "label3";
            label3.Size = new Size(194, 37);
            label3.TabIndex = 2;
            label3.Text = "Calificacion 3";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Segoe UI Emoji", 16.2F, FontStyle.Bold | FontStyle.Italic);
            label4.Location = new Point(76, 408);
            label4.Name = "label4";
            label4.Size = new Size(194, 37);
            label4.TabIndex = 3;
            label4.Text = "Calificacion 4";
            // 
            // textBox1
            // 
            textBox1.Font = new Font("Segoe UI Emoji", 16.2F, FontStyle.Bold | FontStyle.Italic);
            textBox1.Location = new Point(362, 141);
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(125, 43);
            textBox1.TabIndex = 4;
            // 
            // textBox2
            // 
            textBox2.Font = new Font("Segoe UI Emoji", 16.2F, FontStyle.Bold | FontStyle.Italic);
            textBox2.Location = new Point(362, 223);
            textBox2.Name = "textBox2";
            textBox2.Size = new Size(125, 43);
            textBox2.TabIndex = 5;
            // 
            // textBox3
            // 
            textBox3.Font = new Font("Segoe UI Emoji", 16.2F, FontStyle.Bold | FontStyle.Italic);
            textBox3.Location = new Point(362, 314);
            textBox3.Name = "textBox3";
            textBox3.Size = new Size(125, 43);
            textBox3.TabIndex = 6;
            // 
            // textBox4
            // 
            textBox4.Font = new Font("Segoe UI Emoji", 16.2F, FontStyle.Bold | FontStyle.Italic);
            textBox4.Location = new Point(362, 404);
            textBox4.Name = "textBox4";
            textBox4.Size = new Size(125, 43);
            textBox4.TabIndex = 7;
            // 
            // button1
            // 
            button1.BackColor = Color.FromArgb(255, 192, 192);
            button1.Font = new Font("STXihei", 11.999999F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button1.Location = new Point(103, 564);
            button1.Name = "button1";
            button1.Size = new Size(208, 64);
            button1.TabIndex = 8;
            button1.Text = "Decision";
            button1.UseVisualStyleBackColor = false;
            button1.Click += button1_Click;
            // 
            // textBox5
            // 
            textBox5.Font = new Font("Segoe UI Emoji", 16.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            textBox5.Location = new Point(411, 571);
            textBox5.Name = "textBox5";
            textBox5.Size = new Size(137, 43);
            textBox5.TabIndex = 9;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.Cyan;
            ClientSize = new Size(825, 738);
            Controls.Add(textBox5);
            Controls.Add(button1);
            Controls.Add(textBox4);
            Controls.Add(textBox3);
            Controls.Add(textBox2);
            Controls.Add(textBox1);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Icon = (Icon)resources.GetObject("$this.Icon");
            Name = "Form1";
            Text = "calificacion ";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Label label2;
        private Label label3;
        private Label label4;
        private TextBox textBox1;
        private TextBox textBox2;
        private TextBox textBox3;
        private TextBox textBox4;
        private Button button1;
        private TextBox textBox5;
    }
}
