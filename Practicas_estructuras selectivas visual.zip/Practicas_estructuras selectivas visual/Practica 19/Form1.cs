namespace Practica_19
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
         
            try
            {
                // Obtener calificaciones desde los TextBox
                double c1 = double.Parse(textBox1.Text);
                double c2 = double.Parse(textBox2.Text);
                double c3 = double.Parse(textBox3.Text);
                double c4 = double.Parse(textBox4.Text);

                // Calcular promedio
                double promedio = (c1 + c2 + c3 + c4) / 4;

                // Evaluar condiciones
                if (promedio >= 6 && c1 >= 6 && c2 >= 6 && c3 >= 6 && c4 >= 6)
                {
                    textBox5.Text = "Aprobado";
                }
                else
                {
                    textBox5.Text = "Reprobado";
                }
            }
            catch (Exception)
            {
                MessageBox.Show("Ingrese valores num�ricos v�lidos", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

    }
}

