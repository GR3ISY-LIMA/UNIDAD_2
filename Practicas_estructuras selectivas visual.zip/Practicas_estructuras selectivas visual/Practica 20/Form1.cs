namespace Practica_20
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                // Obtener la edad desde el TextBox
                int edad = int.Parse(textBox1.Text);
                string categoria;

                // Evaluar la edad y asignar la categor�a correspondiente
                if (edad < 12)
                {
                    categoria = "Es un Ni�o";
                }
                else if (edad < 18)
                {
                    categoria = "Es un Adolescente";
                }
                else if (edad <= 60)
                {
                    categoria = "Es un Adulto";
                }
                else
                {
                    categoria = "Es un Adulto mayor";
                }

                // Mostrar el resultado en el TextBox2
                textBox2.Text = categoria;
            }
            catch (Exception)
            {
                MessageBox.Show("Ingrese un valor num�rico v�lido", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}

       