namespace Practica_4
{
    public partial class Form1 : Form
    {
        float[] numeros = new float[100]; // Array para almacenar los n�meros
        int indice = 0; // �ndice para controlar la posici�n en el array

        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            float Total = 0;
            int i = 0;
            do
            {
                Total += numeros[i];
                i++;
            } while (i < indice);

            textBox2.Text = Total.ToString();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (indice < numeros.Length) // Verificamos que el array no est� lleno
            {
                listBox1.Items.Add(textBox1.Text);
                numeros[indice] = float.Parse(textBox1.Text);
                indice++;
                textBox1.Text = "";
                textBox1.Focus();
            }
            else
            {
                MessageBox.Show("L�mite de datos alcanzado");
            }
        }
    }
}