﻿namespace Practica_4
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            label1 = new Label();
            label3 = new Label();
            button1 = new Button();
            button2 = new Button();
            listBox1 = new ListBox();
            textBox2 = new TextBox();
            label4 = new Label();
            textBox1 = new TextBox();
            label2 = new Label();
            label5 = new Label();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.BackColor = Color.Fuchsia;
            label1.Font = new Font("Script MT Bold", 18F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.Location = new Point(54, 30);
            label1.Name = "label1";
            label1.Size = new Size(702, 37);
            label1.TabIndex = 0;
            label1.Text = "Este programa toma los numeros capturados y los suma ";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Segoe UI Emoji", 13.8F, FontStyle.Bold | FontStyle.Italic);
            label3.Location = new Point(84, 515);
            label3.Name = "label3";
            label3.Size = new Size(262, 31);
            label3.TabIndex = 2;
            label3.Text = "La suma de todos son:";
            // 
            // button1
            // 
            button1.BackColor = Color.FromArgb(128, 255, 255);
            button1.Font = new Font("Segoe UI Emoji", 13.8F, FontStyle.Bold | FontStyle.Italic);
            button1.Location = new Point(67, 382);
            button1.Name = "button1";
            button1.Size = new Size(147, 76);
            button1.TabIndex = 3;
            button1.Text = "Sumar los numeros ";
            button1.UseVisualStyleBackColor = false;
            button1.Click += button1_Click;
            // 
            // button2
            // 
            button2.BackColor = Color.FromArgb(128, 255, 255);
            button2.Font = new Font("Segoe UI Emoji", 13.8F, FontStyle.Bold | FontStyle.Italic);
            button2.Location = new Point(444, 262);
            button2.Name = "button2";
            button2.Size = new Size(98, 44);
            button2.TabIndex = 4;
            button2.Text = "Añadir";
            button2.UseVisualStyleBackColor = false;
            button2.Click += button2_Click;
            // 
            // listBox1
            // 
            listBox1.BackColor = Color.FromArgb(255, 255, 192);
            listBox1.Font = new Font("Segoe UI Emoji", 13.8F, FontStyle.Bold | FontStyle.Italic);
            listBox1.FormattingEnabled = true;
            listBox1.ItemHeight = 31;
            listBox1.Location = new Point(603, 334);
            listBox1.Name = "listBox1";
            listBox1.Size = new Size(187, 345);
            listBox1.TabIndex = 5;
            // 
            // textBox2
            // 
            textBox2.Font = new Font("Segoe UI Emoji", 13.8F, FontStyle.Bold | FontStyle.Italic);
            textBox2.Location = new Point(414, 512);
            textBox2.Name = "textBox2";
            textBox2.Size = new Size(157, 38);
            textBox2.TabIndex = 7;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Segoe UI Emoji", 13.8F, FontStyle.Bold | FontStyle.Italic);
            label4.Location = new Point(84, 200);
            label4.Name = "label4";
            label4.Size = new Size(255, 31);
            label4.TabIndex = 1;
            label4.Text = "Introduce un numero ";
            // 
            // textBox1
            // 
            textBox1.Font = new Font("Segoe UI Emoji", 13.8F, FontStyle.Bold | FontStyle.Italic);
            textBox1.Location = new Point(414, 204);
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(157, 38);
            textBox1.TabIndex = 6;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI Emoji", 13.8F, FontStyle.Bold | FontStyle.Italic);
            label2.ForeColor = Color.Blue;
            label2.Location = new Point(84, 200);
            label2.Name = "label2";
            label2.Size = new Size(255, 31);
            label2.TabIndex = 1;
            label2.Text = "Introduce un numero ";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Segoe UI Emoji", 13.8F, FontStyle.Bold | FontStyle.Italic);
            label5.ForeColor = Color.Blue;
            label5.Location = new Point(84, 515);
            label5.Name = "label5";
            label5.Size = new Size(262, 31);
            label5.TabIndex = 2;
            label5.Text = "La suma de todos son:";
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(802, 756);
            Controls.Add(textBox2);
            Controls.Add(textBox1);
            Controls.Add(listBox1);
            Controls.Add(button2);
            Controls.Add(button1);
            Controls.Add(label5);
            Controls.Add(label2);
            Controls.Add(label3);
            Controls.Add(label4);
            Controls.Add(label1);
            Icon = (Icon)resources.GetObject("$this.Icon");
            Name = "Form1";
            Text = "suma de num con do while";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Label label3;
        private Button button1;
        private Button button2;
        private ListBox listBox1;
        private TextBox textBox2;
        private Label label4;
        private TextBox textBox1;
        private Label label2;
        private Label label5;
    }
}
