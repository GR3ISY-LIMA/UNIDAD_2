﻿namespace Practica_11
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            label4 = new Label();
            label5 = new Label();
            label6 = new Label();
            button1 = new Button();
            button2 = new Button();
            button3 = new Button();
            button4 = new Button();
            listBox1 = new ListBox();
            listBox2 = new ListBox();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI Emoji", 16.2F, FontStyle.Bold);
            label1.Location = new Point(133, 112);
            label1.Name = "label1";
            label1.Size = new Size(79, 37);
            label1.TabIndex = 0;
            label1.Text = "f(x)=";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI Emoji", 16.2F, FontStyle.Bold);
            label2.Location = new Point(251, 87);
            label2.Name = "label2";
            label2.Size = new Size(31, 37);
            label2.TabIndex = 1;
            label2.Text = "x";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Segoe UI Emoji", 16.2F, FontStyle.Bold);
            label3.Location = new Point(232, 152);
            label3.Name = "label3";
            label3.Size = new Size(78, 37);
            label3.TabIndex = 2;
            label3.Text = "1+x²";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Segoe UI Emoji", 16.2F, FontStyle.Bold);
            label4.Location = new Point(215, 124);
            label4.Name = "label4";
            label4.Size = new Size(108, 37);
            label4.TabIndex = 3;
            label4.Text = "───────";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Segoe UI Emoji", 16.2F, FontStyle.Bold);
            label5.Location = new Point(74, 308);
            label5.Name = "label5";
            label5.Size = new Size(31, 37);
            label5.TabIndex = 4;
            label5.Text = "x";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Segoe UI Emoji", 16.2F, FontStyle.Bold);
            label6.Location = new Point(260, 308);
            label6.Name = "label6";
            label6.Size = new Size(59, 37);
            label6.TabIndex = 5;
            label6.Text = "f(x)";
            // 
            // button1
            // 
            button1.BackColor = Color.Lime;
            button1.Font = new Font("Segoe UI Emoji", 13.8F, FontStyle.Bold | FontStyle.Italic);
            button1.Location = new Point(593, 341);
            button1.Name = "button1";
            button1.Size = new Size(139, 55);
            button1.TabIndex = 6;
            button1.Text = "for";
            button1.UseVisualStyleBackColor = false;
            button1.Click += button1_Click;
            // 
            // button2
            // 
            button2.BackColor = Color.Lime;
            button2.Font = new Font("Segoe UI Emoji", 13.8F, FontStyle.Bold | FontStyle.Italic);
            button2.Location = new Point(593, 434);
            button2.Name = "button2";
            button2.Size = new Size(139, 55);
            button2.TabIndex = 7;
            button2.Text = "while";
            button2.UseVisualStyleBackColor = false;
            button2.Click += button2_Click;
            // 
            // button3
            // 
            button3.BackColor = Color.Lime;
            button3.Font = new Font("Segoe UI Emoji", 13.8F, FontStyle.Bold | FontStyle.Italic);
            button3.Location = new Point(593, 519);
            button3.Name = "button3";
            button3.Size = new Size(139, 55);
            button3.TabIndex = 8;
            button3.Text = "do while";
            button3.UseVisualStyleBackColor = false;
            button3.Click += button3_Click;
            // 
            // button4
            // 
            button4.BackColor = Color.Lime;
            button4.Font = new Font("Segoe UI Emoji", 13.8F, FontStyle.Bold | FontStyle.Italic);
            button4.Location = new Point(593, 620);
            button4.Name = "button4";
            button4.Size = new Size(139, 55);
            button4.TabIndex = 9;
            button4.Text = "salir";
            button4.UseVisualStyleBackColor = false;
            button4.Click += button4_Click;
            // 
            // listBox1
            // 
            listBox1.FormattingEnabled = true;
            listBox1.Location = new Point(28, 371);
            listBox1.Name = "listBox1";
            listBox1.Size = new Size(152, 284);
            listBox1.TabIndex = 10;
            // 
            // listBox2
            // 
            listBox2.FormattingEnabled = true;
            listBox2.Location = new Point(215, 371);
            listBox2.Name = "listBox2";
            listBox2.Size = new Size(152, 284);
            listBox2.TabIndex = 11;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.BlueViolet;
            ClientSize = new Size(793, 681);
            Controls.Add(listBox2);
            Controls.Add(listBox1);
            Controls.Add(button4);
            Controls.Add(button3);
            Controls.Add(button2);
            Controls.Add(button1);
            Controls.Add(label6);
            Controls.Add(label5);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Icon = (Icon)resources.GetObject("$this.Icon");
            Name = "Form1";
            Text = "ECUACION";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Label label2;
        private Label label3;
        private Label label4;
        private Label label5;
        private Label label6;
        private Button button1;
        private Button button2;
        private Button button3;
        private Button button4;
        private ListBox listBox1;
        private ListBox listBox2;
    }
}
